package com.example.banco_crediticio.controller;

import com.example.banco_crediticio.dto.EvaluacionRequestDTO;
import com.example.banco_crediticio.dto.EvaluacionResponseDTO;
import com.example.banco_crediticio.model.HistorialEvaluacion;
import com.example.banco_crediticio.repository.HistorialEvaluacionRepository;
import com.example.banco_crediticio.service.EvaluacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class EvaluacionController {

    private final EvaluacionService evaluacionService;
    private final HistorialEvaluacionRepository historialRepo;

    // POST /evaluar-riesgo
    @PostMapping("/evaluar-riesgo")
    public ResponseEntity<EvaluacionResponseDTO> evaluarCliente(@RequestBody EvaluacionRequestDTO request) {
        EvaluacionResponseDTO resultado = evaluacionService.evaluarCliente(request);
        return ResponseEntity.ok(resultado);
    }

    // GET /historial/{idCliente}
    @GetMapping("/historial/{idCliente}")
    public ResponseEntity<List<HistorialEvaluacion>> obtenerHistorialPorId(@PathVariable Long idCliente) {
        List<HistorialEvaluacion> historial = historialRepo.findByClienteId(idCliente);
        return ResponseEntity.ok(historial);
    }
}

