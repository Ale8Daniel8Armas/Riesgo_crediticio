package com.example.banco_crediticio.model;

import jakarta.persistence.Entity;

@Entity
public class EvaluadorRiesgoBajo extends EvaluadorRiesgo {
    @Override
    public boolean aplica(Cliente cliente) {
        return cliente.getPuntajeCrediticio() >= 80;
    }

    @Override
    public ResultadoEvaluacion evaluar(Cliente cliente) {
        int puntajeFinal = calcularPuntajeFinal(cliente);
        return ResultadoEvaluacion.builder()
                .nivelRiesgo(determinarNivelRiesgo(puntajeFinal))
                .aprobado(true)
                .puntajeFinal(puntajeFinal)
                .mensaje("Cliente con riesgo bajo")
                .tasaInteres(0.05)
                .plazoAprobado(cliente.getPlazoEnMeses())
                .build();
    }
}
