package com.example.banco_crediticio.repository;

import com.example.banco_crediticio.model.ResultadoEvaluacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EvaluacionRepository extends JpaRepository<ResultadoEvaluacion, Long> {

}

