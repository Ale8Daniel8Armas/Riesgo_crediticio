package com.example.banco_crediticio.model;

import com.example.banco_crediticio.model.HistorialEvaluacion;
import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name="EvaluacionRiesgo")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED)

public abstract class EvaluadorRiesgo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double puntajeBase;

    @OneToOne(cascade = CascadeType.ALL) // Relación uno a uno
    @JoinColumn(name = "historial_id") // Columna en la tabla EvaluadorRiesgo
    private HistorialEvaluacion historial;

    public abstract boolean aplica(Cliente cliente);
    public abstract ResultadoEvaluacion evaluar(Cliente cliente);

    public int calcularPuntajeFinal(Cliente cliente){
        int puntajeFinal = 100;

        if(historial.getTipoCliente().equalsIgnoreCase("NATURAL")){
            if(cliente.getPuntajeCrediticio() < 650){
                puntajeFinal -= 30;
            }

            if(cliente.getMontoDeuda() > (cliente.getIngresoReferencial() * 0.4)){
                puntajeFinal -= 15;
            }

            if(cliente.getMontoSolicitado() > (cliente.getIngresoReferencial() * 0.5)){
                puntajeFinal -= 10;
            }
        }

        if(historial.getTipoCliente().equalsIgnoreCase("JURIDICA")){
            if(cliente.getPuntajeCrediticio() < 650){
                puntajeFinal -= 30;
            }

            if(cliente.getMontoDeuda() > (cliente.getIngresoReferencial() * 0.35)){
                puntajeFinal -= 20;
            }

            if(cliente.getMontoSolicitado() > (cliente.getIngresoReferencial() * 0.3)){
                puntajeFinal -= 15;
            }
        }
        return puntajeFinal;
    }

    public String determinarNivelRiesgo(int puntaje){
        if (puntaje >= 80) return "BAJO";
        if (puntaje <= 79 && puntaje >= 60) return "MEDIO";
        return "ALTO";
    }
}
