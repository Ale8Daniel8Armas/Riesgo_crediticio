package com.example.banco_crediticio.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@Table(name = "Deudas")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Getter
@Setter

public class Deuda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double monto;
    private int plazoMeses;
}

