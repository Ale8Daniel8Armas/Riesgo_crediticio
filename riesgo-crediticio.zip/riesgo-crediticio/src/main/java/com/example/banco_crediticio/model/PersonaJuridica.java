package com.example.banco_crediticio.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@Table(name = "PersonasJuridicas")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

public class PersonaJuridica extends Cliente{

    private int antiguedadAnios;
    private double ingresoAnual;
    private int empleados;

    @Override
    public double getIngresoReferencial() {
        return ingresoAnual;
    }

    @Override
    public boolean esAptoParaCredito() {
        return getPuntajeCrediticio() > 650 && antiguedadAnios >= 2;
    }
}
