package com.example.banco_crediticio.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@Table(name = "PersonasNaturales")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString

public class PersonaNatural extends Cliente{

    private int Edad;
    private double ingresoMensual;

    @Override
    public double getIngresoReferencial() {
        return ingresoMensual * 12;
    }

    @Override
    public boolean esAptoParaCredito() {
        return getPuntajeCrediticio() > 650 && Edad >= 18;
    }
}
