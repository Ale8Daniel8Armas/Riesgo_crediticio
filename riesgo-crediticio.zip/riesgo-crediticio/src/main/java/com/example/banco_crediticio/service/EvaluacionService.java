package com.example.banco_crediticio.service;

import com.example.banco_crediticio.dto.EvaluacionRequestDTO;
import com.example.banco_crediticio.dto.EvaluacionResponseDTO;
import com.example.banco_crediticio.model.*;
import com.example.banco_crediticio.repository.HistorialEvaluacionRepository;
import com.example.banco_crediticio.repository.PersonaNaturalRepository;
import com.example.banco_crediticio.repository.PersonaJuridicaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Transactional
public class EvaluacionService {

    private final HistorialEvaluacionRepository historialRepo;
    private final PersonaNaturalRepository personaNaturalRepo;
    private final PersonaJuridicaRepository personaJuridicaRepo;

    public EvaluacionResponseDTO evaluarCliente(EvaluacionRequestDTO request) {
        Cliente cliente;

        // Crear y guardar el cliente según el tipo
        if (request.getTipoCliente().equalsIgnoreCase("NATURAL")) {
            PersonaNatural persona = new PersonaNatural();
            persona.setEdad(request.getEdad());
            persona.setIngresoMensual(request.getIngresoMensual());

            // Datos comunes
            persona.setNombre(request.getNombre());
            persona.setPuntajeCrediticio(request.getPuntajeCrediticio());
            persona.setMontoSolicitado(request.getMontoSolicitado());
            persona.setPlazoEnMeses(request.getPlazoEnMeses());
            persona.setDeudasActuales(
                    request.getDeudasActuales().stream().map(dto -> {
                        Deuda deuda = new Deuda();
                        deuda.setMonto(dto.getMonto());
                        deuda.setPlazoMeses(dto.getPlazoMeses());
                        return deuda;
                    }).toList()
            );

            cliente = personaNaturalRepo.save(persona);
        } else {
            PersonaJuridica empresa = new PersonaJuridica();
            empresa.setAntiguedadAnios(request.getAntiguedadAnios());
            empresa.setIngresoAnual(request.getIngresoAnual());
            empresa.setEmpleados(request.getEmpleados());

            // Datos comunes
            empresa.setNombre(request.getNombre());
            empresa.setPuntajeCrediticio(request.getPuntajeCrediticio());
            empresa.setMontoSolicitado(request.getMontoSolicitado());
            empresa.setPlazoEnMeses(request.getPlazoEnMeses());
            empresa.setDeudasActuales(
                    request.getDeudasActuales().stream().map(dto -> {
                        Deuda deuda = new Deuda();
                        deuda.setMonto(dto.getMonto());
                        deuda.setPlazoMeses(dto.getPlazoMeses());
                        return deuda;
                    }).toList()
            );

            cliente = personaJuridicaRepo.save(empresa);
        }

        // Evaluar puntaje final
        int puntaje = calcularPuntajeFinal(cliente);
        String nivelRiesgo = determinarNivelRiesgo(puntaje);
        boolean aprobado = puntaje >= 60;
        double tasaInteres;
        int plazoAprobado;

        if (puntaje >= 80) {
            tasaInteres = 6.5;
            plazoAprobado = cliente.getPlazoEnMeses();
        } else if (puntaje >= 60 && puntaje < 80) {
            tasaInteres = 8.0;
            plazoAprobado = cliente.getPlazoEnMeses();
        } else {
            tasaInteres = 0.0;
            plazoAprobado = 0;
        }

        // Crear y guardar historial
        HistorialEvaluacion historial = new HistorialEvaluacion();
        historial.setCliente(cliente);
        historial.setClienteNombre(cliente.getNombre());
        historial.setTipoCliente(request.getTipoCliente());
        historial.setMontoSolicitado(cliente.getMontoSolicitado());
        historial.setPlazoEnMeses(cliente.getPlazoEnMeses());
        historial.setNivelRiesgo(nivelRiesgo);
        historial.setAprobado(aprobado);
        historial.setFechaConsulta(LocalDateTime.now());
        historialRepo.save(historial);

        // Crear respuesta
        return construirResponse(aprobado, nivelRiesgo, puntaje, tasaInteres, plazoAprobado);
    }

    private EvaluacionResponseDTO construirResponse(boolean aprobado, String nivelRiesgo,
                                                    int puntaje, double tasaInteres, int plazoAprobado) {
        EvaluacionResponseDTO response = new EvaluacionResponseDTO();
        response.setAprobado(aprobado);
        response.setNivelRiesgo(nivelRiesgo);
        response.setPuntajeFinal(puntaje);
        response.setTasaInteres(tasaInteres);
        response.setPlazoAprobado(plazoAprobado);

        if (!aprobado) {
            response.setMensaje("Cliente no apto para crédito");
        } else if (puntaje >= 80) {
            response.setMensaje("Crédito aprobado con condiciones estándar");
        } else {
            response.setMensaje("Crédito aprobado con condiciones ajustadas");
        }

        return response;
    }

    private int calcularPuntajeFinal(Cliente cliente) {
        int puntaje = 100;

        if (cliente.getPuntajeCrediticio() < 650) {
            puntaje -= 30;
        }

        double totalDeudas = cliente.getMontoDeuda();

        if (cliente instanceof PersonaNatural) {
            PersonaNatural pn = (PersonaNatural) cliente;
            double ingresoMensual = pn.getIngresoMensual();

            if (totalDeudas > 0.4 * ingresoMensual) {
                puntaje -= 15;
            }

            if (cliente.getMontoSolicitado() > 0.5 * ingresoMensual) {
                puntaje -= 10;
            }

        } else if (cliente instanceof PersonaJuridica) {
            PersonaJuridica pj = (PersonaJuridica) cliente;
            double ingresoAnual = pj.getIngresoAnual();

            if (totalDeudas > 0.35 * ingresoAnual) {
                puntaje -= 20;
            }

            if (cliente.getMontoSolicitado() > 0.3 * ingresoAnual) {
                puntaje -= 15;
            }
        }

        return Math.max(puntaje, 0);
    }

    private String determinarNivelRiesgo(int puntaje) {
        if (puntaje >= 80) return "Bajo";
        if (puntaje >= 60) return "Medio";
        return "Alto";
    }
}