package com.example.banco_crediticio.dto;

import lombok.Data;

import java.util.List;

@Data
public class EvaluacionRequestDTO {

    private String tipoCliente;
    private String nombre;
    private int puntajeCrediticio;
    private double montoSolicitado;
    private int plazoEnMeses;

    // Persona Natural
    private Integer edad;
    private Double ingresoMensual;

    // Persona Jurídica
    private Integer antiguedadAnios;
    private Double ingresoAnual;
    private Integer empleados;

    // Deudas actuales
    private List<DeudaDTO> deudasActuales;
}

