package com.example.banco_crediticio.model;

import jakarta.persistence.Entity;

@Entity
public class EvaluadorRiesgoMedio extends EvaluadorRiesgo {
    @Override
    public boolean aplica(Cliente cliente) {
        int score = cliente.getPuntajeCrediticio();
        return score >= 60 && score < 80;
    }

    @Override
    public ResultadoEvaluacion evaluar(Cliente cliente) {
        int puntajeFinal = calcularPuntajeFinal(cliente);
        return ResultadoEvaluacion.builder()
                .nivelRiesgo(determinarNivelRiesgo(puntajeFinal))
                .aprobado(true)
                .puntajeFinal(puntajeFinal)
                .mensaje("Cliente con riesgo medio")
                .tasaInteres(0.10)
                .plazoAprobado(cliente.getPlazoEnMeses())
                .build();
    }
}

