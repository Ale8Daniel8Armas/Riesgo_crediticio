package com.example.banco_crediticio.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Data
@Entity
@Table(name = "clientes")
@NoArgsConstructor
@AllArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private int puntajeCrediticio;
    private double montoSolicitado;
    private int plazoEnMeses;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Deuda> deudasActuales;

    public abstract double getIngresoReferencial();
    public abstract boolean esAptoParaCredito();

    public double getMontoDeuda() {
        return deudasActuales.stream().mapToDouble(Deuda::getMonto).sum();
    }
}
